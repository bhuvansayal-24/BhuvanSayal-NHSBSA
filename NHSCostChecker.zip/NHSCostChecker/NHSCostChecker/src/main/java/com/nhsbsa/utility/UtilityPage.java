package com.nhsbsa.utility;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;

public class UtilityPage extends Configuration {


	public static UtilityPage instance;
	public String Landing_url ;
	public String ExpectedLandingUrl;
	public String landingUrlFilePath = ".//src//main//java//com//nhsbsa//propertyfiles//NaviagtionUrl.properties";

	public UtilityPage() {
		PageFactory.initElements(driver, this);
	}

	public static UtilityPage getInstance() {
		if (instance == null) {
			synchronized (UtilityPage.class) {
				if(instance == null) {
					instance = new UtilityPage();
				}

			}
		}
		return instance;
	}

	public void launchBrowserUrl(String url) {
		driver.get(url);

	}
	public String expectedLandingUrlfetch(String str) throws IOException {

		ExpectedLandingUrl = Configuration.customPropertyFetchMethod(str, landingUrlFilePath);
		return ExpectedLandingUrl;
	}
	
	public String[] dob_retrieve(String DOB) {

		String[] Birthdate ;

		Birthdate = DOB.split("-");
		if (Birthdate.length == 1) {
			Birthdate = DOB.split("/");
		}

		return Birthdate;		

	}




}
