package com.nhsbsa.utility;


import org.openqa.selenium.WebElement;

public class Actions extends Configuration{

	public void webElementClick(WebElement element) {

		element.click();

	}

	public void findWebElement_clearTxt(WebElement element){
		element.clear();
	}

	public void passTxtToWebElement(WebElement element, String txt) {
		element.sendKeys(txt);
	}

	public String fetchTxtFromWebElement(WebElement element) {

		return element.getText();
	}
}