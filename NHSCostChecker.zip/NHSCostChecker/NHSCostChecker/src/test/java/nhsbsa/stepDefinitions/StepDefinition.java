package nhsbsa.stepDefinitions;

import com.nhsbsa.pages.CostsCheckerPage;
import com.nhsbsa.utility.Configuration;
import com.nhsbsa.utility.UtilityPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition {
	
	public String StartUrl;
	UtilityPage cost_checker = UtilityPage.getInstance();
	CostsCheckerPage cost_checker_actions = new CostsCheckerPage();

	
	
	       @Given("^I navigate to NHS costs checker website$") 
	       public void nhsCostsCheckerNavigation() throws Exception {

		   StartUrl = Configuration.propertyMethod("environmentUrl");
		   cost_checker.launchBrowserUrl(StartUrl);		
	   }
		
	       @When("^I want to check my NHS cost eligibility")
	       public void clickOnStartButton() throws Exception {
	    	   cost_checker_actions.clickStartNowButton();
	   }
	 
	       @And("^I navigate to the next page")
	       public void clickOnNextButton() throws Exception {
	    	   cost_checker_actions.clickNextButton();
	   }

	       @When("^I live in England")
	       public void clickOnEnglandRadioBtn() throws Exception {
	    	   cost_checker_actions.clickPlaceEngland();
	    	   cost_checker_actions.clickNextButton();
	   }
	   
	       @And("^My GP Practice is in England")
	       public void clickYesRadioButton() throws Exception {
	    	   cost_checker_actions.clickYesRadioButton();
	    	   cost_checker_actions.clickNextButton();
	   }
	 
	        @And("^My dental prcatice is in England")
	        public void clickRadioEngland() throws Exception {
	        	cost_checker_actions.clickRadioEngland();
	        	cost_checker_actions.clickNextButton();
	   }
	   
	   
		    @And ("^I enter my date of birth as '(.+)'$")
		    public void validate_and_enter_DOB(String DOB) {
		    	String[] Birthdate;
		    	Birthdate = cost_checker.dob_retrieve(DOB);
		    	cost_checker_actions.input_value_DOB_Day(Birthdate[0]);
		    	cost_checker_actions.input_value_DOB_Month(Birthdate[1]);
		    	cost_checker_actions.input_value_DOB_Year(Birthdate[2]);
		    	cost_checker_actions.clickNextButton();
		}
		
		    @And("^I live with Partner")
		    public void clickpartner_Yes() throws Exception {
		    	cost_checker_actions.clickpartner_Yes();
		    	cost_checker_actions.clickNextButton();
		}
	     
		    @And("^I and my partner claim any tax benefits")
		    public void clickTaxClaimBenifit() throws Exception {
		    	cost_checker_actions.clickTaxClaimBenifit();
		    	cost_checker_actions.clickNextButton();
		}		   
		   	   
		    @And("^I paid Universal Credit")
		    public void clickUnv_creditPaid() throws Exception {
		    	cost_checker_actions.clickUnv_creditPaid();
		    	cost_checker_actions.clickNextButton();
		}
		   
		    @And("^I Joint Universal credit")
		   public void clickUnv_creditclaim_yes() throws Exception {
			  cost_checker_actions.clickUnv_creditclaim_yes();
			  cost_checker_actions.clickNextButton();
		}

		    @And("^Our combined take-home pay is more than 935")
		   public void clickUnv_credit_takeaway_yes() throws Exception {
			  cost_checker_actions.clickUnv_credit_takeaway_yes();
			  cost_checker_actions.clickNextButton();
		}
		   
			@Then("^I get help with NHS costs")
			public void validate_costs_eligibility() {
				String Result_reason ;
				Result_reason = cost_checker_actions.ValidateResult();
				System.out.println("************************** "+ Result_reason+" **************************");
				System.out.println("Based on what you've told us\\nYou get help with NHS costs");
		}

			
			@Then("^I get help with NHS costs beacause you are under 16")
			public void validate_costs_eligibility_underage() {
				String Result_reason ;
				Result_reason = cost_checker_actions.ValidateResult();
				System.out.println("************************** "+ Result_reason+" **************************");
				System.out.println("I get help with NHS costs beacause you are under 16");
		}
	
			@And("^I live in NorthernIreland")
			public void ClickOnNorthernIrelandRadioBtn() throws Exception {
				  cost_checker_actions.ClickPlaceNorthIreland();
				  cost_checker_actions.clickNextButton();
		}
			
			@Then("^I cannot use this service because I live in Northern Ireland")
			public void validate_costs_eligibility_from_NorthIreland() {
				String Result_reason;
				Result_reason = cost_checker_actions.ValidateResult_NorthIreland();
				System.out.println("************************** "+ Result_reason+" **************************");
				System.out.println("You cannot use this service because you live in Northern Ireland");
	     }
			
}
