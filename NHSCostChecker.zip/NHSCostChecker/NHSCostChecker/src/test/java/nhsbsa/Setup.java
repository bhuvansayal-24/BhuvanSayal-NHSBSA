package nhsbsa;

import com.nhsbsa.utility.Configuration;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;


public class Setup extends Configuration {
	
	@Before
	  public void setUp() throws Exception {
		System.out.println("OPEN BROWSER_________####################################");
		  Configuration.getInstance().browserSelection();
		
	  }
	@After
	public void tearDown(Scenario scenario) throws Exception {
		
		Configuration.implicitWait();
		Configuration.closeBrowser();
		
	  }
}
